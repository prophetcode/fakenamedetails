import React from 'react'

const Header = ({ pageTitle }) => {
  return (
      <header>
        <h1 className='text-3xl font-extrabold'>{pageTitle}</h1>
      </header>
  )
}

export default Header