import React, { useState, useEffect } from "react";
import Header from "./Components/Header";
import MainContent from "./Components/MainContent"

//create my url varibles
const baseUrl = "https://jsonplaceholder.typicode.com/";
let endpoitUrl= "users"
function App() {
//my api base url
  
  
  const [pageTitle] = useState("Fake Users");
  const [users, setUsers] = useState([
    {
      "id": null,
      "name": null,
      "username": null,
      "email": null,
      "address": {
        "street": null,
        "suite": null,
        "city": null,
        "zipcode": null,
        "geo": {
          "lat": null,
          "lng": null
        }
      },
      "phone": null,
      "website": null,
      "company": {
        "name": null,
        "catchPhrase": null,
        "bs": null
      }
    }
  ]);
  //set loading state
   const [loading, setLoading] = useState(true);

const getUsers= async()=>{
setLoading(true)
  try{
    const response = await fetch(baseUrl + endpoitUrl);
    const data = await response.json()
    setUsers(data)
    setLoading(false)
  }catch(error){
    setLoading(false)
  }
}

//use effect hook to call the api
useEffect(() => {
  getUsers()
}, [])

  return (
    <div className="h-[100svh] bg-[#f5f5f5]">
      <Header pageTitle ={pageTitle}/>
      <MainContent users={users} loading={loading} className="h-full grid  lg:grid-cols-[15rem_1fr] grid-cols-1 sm:grid-cols-[5rem_1fr]" />
    </div>
  );
}

export default App;
